﻿Cấu hình tất cả trong file: 2T_config/config_server.php
import file data.sql
crons các file
viplike.php
vipcmt.php
botToken.php
done =)