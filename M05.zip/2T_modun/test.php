<?php
	require_once 'modun_function.php';
	$result = array('a','b','c');
	$result['a'] = 1;
?>

