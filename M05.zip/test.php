<?php
	/*$xml = simplexml_load_file("https://chantroimoimedia.com/feed/");
	foreach($xml->channel->item as $itm){
		$title = $itm->title;
		echo $title.'<br>';
	}*/
	echo time();
?>
